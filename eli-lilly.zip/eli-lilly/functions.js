const csvFileUrl = './population.csv';
let populationData = [];
let yearDropDown = document.getElementById('YearDropDown');
let selectedYear = document.getElementById('SelectedYear');
let populationTotal = document.getElementById('PopulationTotal');
let filteredDataSelectedYearAllData;
let filteredDataTotalTillSelectedYear;
let populationDensityValuesSelectedYear = '';
let populationGrowthValuesSelectedYear = '';
let desktopXAxisValues = [200, 400, 600, 800, 1000];
let mobileXAxisValues = [0, 400, 800, 1000];
let yAxisValues = [-100, 0, 100];

let svgWidth = window.innerWidth < 800 ? 400 : 1000
let svgHeight = 500;
let margin = 70;
let svgTag = d3.select('#SVG-TAG');
let tooltip = d3.select("#Tooltip");
let oneMillion = 1000000;
let staticChart = document.querySelector('#StaticChart');

//====================================


/*   const svgStaticWidth = 600; */

const svgStaticWidth = window.innerWidth < 900 ? 300 : 500
const svgStaticHeight = 180;
const marginPopulation = {
    top: 15,
    right: 0,
    bottom: 20,
    left: 0
};

const width = svgStaticWidth - marginPopulation.left - marginPopulation.right;
const height = svgStaticHeight - marginPopulation.top - marginPopulation.bottom;

const svgStaticGraph = d3.select('#StaticPopulation')
    .attr('width', svgStaticWidth)
    .attr('height', svgStaticHeight);

const g = svgStaticGraph.append('g')
    .attr('transform', `translate(${marginPopulation.left +10},${marginPopulation.top})`);


d3.csv(csvFileUrl, d => {
    d.Year = +d.Year;
    d.Population = +d.Population.replace(/,/g, '');
    return d;
}).then(data => {


    const yearPopulationTotals = d3.rollup(
        data,
        v => d3.sum(v, d => d.Population),
        d => d.Year
    );


    const areaData = Array.from(yearPopulationTotals, ([year, population]) => ({
        year,
        population
    }));


    areaData.sort((a, b) => a.year - b.year);


    let cumulativeTotal2021 = 0;
    areaData.forEach(d => {
        if (d.year <= 2021) {
            cumulativeTotal2021 += d.population;
        }
        d.cumulativeTotal = cumulativeTotal2021;
    });


    let cumulativeTotal1950 = 0;
    areaData.forEach(d => {
        if (d.year <= 1950) {
            cumulativeTotal1950 += d.population;
        }
    });


    const areaGenerator = d3.area()
        .x(d => x(d.year))
        .y0(height)
        .y1(d => y(d.cumulativeTotal));


    const x = d3.scaleLinear()
        .domain(d3.extent(areaData, d => d.year))
        .range([0, width]);

    const y = d3.scaleLinear()
        .domain([0, d3.max(areaData, d => d.cumulativeTotal)])
        .range([height, 0]);


    g.append('path')
        .datum(areaData)
        .attr('fill', '#FFDA6B')
        .attr('d', areaGenerator);




    g.append('g')
        .attr('transform', `translate(0,${height})`)
        .call(d3.axisBottom(x).tickValues([d3.min(areaData, d => d.year), d3.max(areaData, d => d
            .year)]).tickFormat(d3.format("d")));


    const tooltipStatic = d3.select('#StaticChart').select('.tooltipStatic');
    const staticChart = document.getElementById('StaticChart');

    svgStaticGraph.on('mousemove', function () {
        const mouseX = d3.mouse(this)[0];
        const mouseY = d3.mouse(this)[1];
        const centerX = width / 2;
        const centerY = height / 2;
        const year = Math.round(x.invert(mouseX));
        const totalPopulation = yearPopulationTotals.get(year);
        const cumulativeTotalForYear = areaData.find(d => d.year === year).cumulativeTotal;

        tooltipStatic.style('opacity', 0.9);

        if (totalPopulation !== undefined) {
            const tooltipWidth = tooltipStatic.node().getBoundingClientRect().width;
            const tooltipHeight = tooltipStatic.node().getBoundingClientRect().height;

            let leftPosition, topPosition;

            if (mouseX < centerX) {
                leftPosition = mouseX + 10;
            } else {
                leftPosition = mouseX - tooltipWidth -
                    10;
            }

            if (mouseY < centerY) {

                topPosition = mouseY + 10;
            } else {

                topPosition = mouseY - tooltipHeight -
                    10;
            }

            tooltipStatic.html(
                    `Year: ${year}<br>Total Population: ${(totalPopulation / oneMillion).toFixed(2)} Mn<br>Total (until  ${year}): ${(cumulativeTotalForYear / oneMillion).toFixed(2)} Mn`
                )
                .style('left', `${leftPosition}px`)
                .style('top', `${topPosition}px`);
        }
    });


    svgStaticGraph.on('mouseout', function () {
        tooltipStatic.style('opacity', 0);
    });


    const total1950 = areaData.find(d => d.year === 1950).cumulativeTotal;
    const total2021 = areaData.find(d => d.year === 2021).cumulativeTotal;
    const x1950 = x(1950);
    const x2021 = x(2021);



    const lineData = areaData.filter(d => d.year >= 1950 && d.year <= 2021);


    const lineGenerator = d3.line()
        .x(d => x(d.year))
        .y(d => y(d.cumulativeTotal))
        .curve(d3.curveBasis);


    g.append('path')
        .datum(lineData)
        .attr('fill', 'none')
        .attr('stroke', '#FC9D50')
        .attr('stroke-width', 3)
        .attr('d', lineGenerator);


    if (!isNaN(total1950)) {
        g.append('text')
            .attr('x', x(1950) + 10)
            .attr('y', y(total1950))
            .attr('dy', -15)
            .style('text-anchor', 'start')
            .text(`${(total1950 / oneMillion).toFixed(2)} Mn`);
    }

    if (!isNaN(total2021)) {
        g.append('text')
            .attr('x', x(2021) - 70)
            .attr('y', y(total2021))
            .attr('dy', -5)
            .style('text-anchor', 'start')
            .text(`${(total2021 / oneMillion).toFixed(2)} Mn`);
    }
});




document.addEventListener("DOMContentLoaded", function () {

    yearDropDown.value = "1950";


    var event = new Event('change');
    yearDropDown.dispatchEvent(event);

    selectedYear.textContent = '(1950)';
    populationTotal.innerHTML = `2.48 <span class="million">Mn <span>`;


});


function loadDefaultChart(population) {
    let currentYear = yearDropDown.value;

    const allYears = population.map(y => y.Year);
    let finalYears = [...new Set(allYears)];

    for (const finalYear of finalYears) {
        let options = `<option value="${finalYear}">Year: ${finalYear}</option>`;
        yearDropDown.insertAdjacentHTML('beforeend', options);
    }

    let separateYearsData = {};
    population.forEach(y => {
        let years = y.Year;
        if (!separateYearsData[years]) {
            separateYearsData[years] = [];
        }
        separateYearsData[years].push(y);
    });



    filteredDataSelectedYearAllData = separateYearsData[currentYear] || [];

    if (!filteredDataSelectedYearAllData.length) {
        populationTotal.textContent = "No data available for the selected year.";
        return;
    }

    let selectedYearCount = filteredDataSelectedYearAllData.reduce((acc, cur) => {
        let populationVal = cur['Population'];
        const populationCheck = typeof populationVal === 'string' ? parseInt(
            populationVal) : populationVal;

        if (!isNaN(populationCheck)) {
            return acc + populationCheck;
        }

        return acc;
    }, 0);




    let tillFilteredYearsCount = (population.filter(f => f.Year <= currentYear).map(m => m
            .Population)
        .reduce((cur, acc) => cur + acc, 0) / oneMillion).toFixed(2)



    //((currentYear * (currentYear + 1) / 2) / 1000000).toFixed(2);


    selectedYear.innerHTML = `(${currentYear})`;
    populationTotal.innerHTML = tillFilteredYearsCount + `<span class="million">Mn <span>`;



    populationDensityValuesSelectedYear = filteredDataSelectedYearAllData.map((de) => {
        return de.Population_Density;
    });

    populationGrowthValuesSelectedYear = filteredDataSelectedYearAllData.map((density) => {
        return density.Population_Growth_Rate;
    });

    svgTag.attr('width', svgWidth).attr('height', svgHeight);

    let yScale = d3.scaleLinear().domain([-100, 100]).range([svgHeight - margin, margin]);

    let yAxis = d3.axisLeft(yScale).tickValues(yAxisValues);


    svgTag.select(".y-axis").remove();

    svgTag.append("g")
        .attr("class", "y-axis")
        .attr("transform", "translate(50, 0)")
        .call(yAxis);

    svgTag.append("text")
        .attr("x", 10)
        .attr("y", 20)
        .attr("fill", "black")
        .attr("font-size", 12)
        .attr("transform", `rotate(-90) translate(-${parseInt(svgHeight/1.7)},10)`)
        .text("Population Growth(%)");

    const windowWidth = window.innerWidth;

    const xTickValues = windowWidth < 700 ? mobileXAxisValues : desktopXAxisValues;

    const xScale = d3.scaleLinear()
        .domain([0, 1000])
        .range([50, svgWidth - margin]);

    const xAxis = d3.axisBottom(xScale)
        .tickValues(xTickValues);

    svgTag.select(".x-axis").remove();

    svgTag.append("g")
        .attr("class", "x-axis")
        .attr("transform", `rotate(0) translate(0,${svgHeight-70})`)
        .call(xAxis);

    svgTag.append("text")
        .attr("x", 10)
        .attr("y", 20)
        .attr("fill", "black")
        .attr("font-size", 12)
        .attr("transform", `rotate(0) translate(${parseInt(svgWidth/2.3)},${svgHeight-margin+20})`)
        .text("Population Density");
    clearCircles();

    let densityCircle = populationDensityValuesSelectedYear;
    let growthCircle = populationGrowthValuesSelectedYear;

    updatedCircles(densityCircle, growthCircle, xScale, yScale);
}


function populationFunction(population) {
    const currentYear = '1950';
    loadDefaultChart(population)

    yearDropDown.addEventListener('change', (val) => {
        const currentYear = val.target.value;
        population.map(s => {
            s.Population = s.Population === '' ? 0 : s.Population;
            s.Population_Density = s.Population_Density === '' ? 0 : s.Population_Density;
            s.Population_Growth_Rate = s.Population_Growth_Rate === '' || s.Population_Growth_Rate === NaN ? 0 : s
                .Population_Growth_Rate;

        })
        loadDefaultChart(population);



    });
}



function hideTooltip() {
    tooltip.style("display", "none");
}

function updatedCircles(density, growth, xScale, yScale) {
    const dataPairs = density.map((d, i) => ({
        density: d,
        growth: growth[i],
        data: filteredDataSelectedYearAllData[i],
    }));



    svgTag.selectAll("line").remove();


    svgTag.selectAll("circle")
        .data(dataPairs)
        .enter()
        .append("circle")
        .attr('cursor', 'pointer')
        .attr("cx", (d) => xScale((d.density) + 5).toFixed(0))
        .attr("cy", (d) => yScale(d.growth).toFixed(0))
        .attr("r", 5)
        .attr("fill", "blue")

        .on('mouseover', function (event, d) {
            d3.select(this)
                .transition()
                .duration(200)
                .attr("r", 10);

            const circle = d3.select(this);
            const cx = parseFloat(circle.attr("cx"));
            const cy = parseFloat(circle.attr("cy"));
            const tooltipWidth = tooltip.node().getBoundingClientRect().width;
            const tooltipHeight = tooltip.node().getBoundingClientRect().height;

            let countryObject = event.data;

            let tooltipX, tooltipY;

            if (cx <= svgWidth / 2) {

                tooltipX = cx + 15;
            } else {

                tooltipX = cx - tooltipWidth - 15;
            }

            if (cy <= svgHeight / 2) {

                tooltipY = cy + 15;
            } else {

                tooltipY = cy - tooltipHeight - 15;
            }



            const tooltipContent = `
                        <strong>Country:</strong> ${countryObject.Country}<br>
                        <strong>Year:</strong> ${countryObject.Year}<br>
                        <strong>Population:</strong> ${countryObject.Population}<br>
                        <strong>Population Density:</strong> ${countryObject.Population_Density}<br>
                        <strong>Population Growth Rate:</strong> ${countryObject.Population_Growth_Rate} 
                    `;




            tooltip.html(tooltipContent)
                .style("left", tooltipX + "px")
                .style("top", tooltipY + "px")
                .style("display", "block");

        })

        .on('mouseout', function (e) {

            const circle = d3.select(this);

            circle.transition().duration(200).attr("r", 5);

            hideTooltip();
        });
}

function clearCircles() {
    svgTag.selectAll("circle").remove();
}

d3.csv(csvFileUrl, (d) => {

    d.Population = parseInt(d.Population.replace(/,/g, ''), 10);

    d.Population_Density = parseFloat(d.Population_Density);
    d.Population_Growth_Rate = parseFloat(d.Population_Growth_Rate);
    return d;
}).then(function (data) {
    populationData.push(data);
    populationFunction(data);


    loadDefaultChart(data)


});